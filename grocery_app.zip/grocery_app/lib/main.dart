import 'package:flutter/material.dart';
import 'utils/colors.dart';
import 'screens/home_screen.dart';
import 'screens/categories_screen.dart';
import 'screens/favorites_screen.dart';
import 'screens/cart_screen.dart';
import 'screens/profile_screen.dart';
import 'screens/login_screen.dart';
import 'screens/signup_screen.dart';
import 'services/auth_service.dart';
import 'services/app_state.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(AppStateProvider(state: AppState(), child: const GroceryApp()));
}

class GroceryApp extends StatelessWidget {
  const GroceryApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final theme = ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(
        seedColor: AppColors.primary,
        brightness: Brightness.light,
      ),
      scaffoldBackgroundColor: AppColors.background,
      appBarTheme: const AppBarTheme(
        elevation: 0,
        backgroundColor: Colors.transparent,
        foregroundColor: Colors.black,
        centerTitle: false,
      ),
      textTheme: const TextTheme(
        titleLarge: TextStyle(fontWeight: FontWeight.bold),
      ),
    );

    return MaterialApp(
      title: 'Grocery App',
      debugShowCheckedModeBanner: false,
      theme: theme,
      home: AuthGate(
        child: const _RootNavigator(),
      ),
    );
  }
}

class AuthGate extends StatefulWidget {
  final Widget child;
  const AuthGate({Key? key, required this.child}) : super(key: key);

  @override
  State<AuthGate> createState() => _AuthGateState();
}

class _AuthGateState extends State<AuthGate> {
  final AuthService _auth = AuthService();
  bool _isSignup = false;
  bool _hasAnyUsers = false;

  void _toSignup() => setState(() => _isSignup = true);
  void _toLogin() => setState(() => _isSignup = false);

  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
      future: _initialize(),
      builder: (context, snapshot) {
        if (snapshot.connectionState != ConnectionState.done) {
          return const Scaffold(
            body: Center(child: CircularProgressIndicator()),
          );
        }
        return AnimatedBuilder(
      animation: _auth,
      builder: (context, _) {
        if (_auth.isLoggedIn) {
      return _AppBootstrap(auth: _auth, child: widget.child);
        }
            // If users exist, default to Login screen; else, default to Signup.
            final showSignup = _hasAnyUsers ? _isSignup : !_hasAnyUsers || _isSignup;
            return showSignup
            ? SignupScreen(
                onSignup: ({required String name, required String email, required String password}) async {
                  try {
                    await _auth.signup(name: name, email: email, password: password);
                        // After successful signup, switch to Login.
    setState(() {
                          _hasAnyUsers = true;
                          _isSignup = false;
                        });
                  } catch (e) {
                    if (context.mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text(e.toString())),
                      );
                    }
                  }
                },
                onGoToLogin: _toLogin,
              )
            : LoginScreen(
                onLogin: ({required String email, required String password}) async {
                  try {
                    await _auth.login(email: email, password: password);
                  } catch (e) {
                    if (context.mounted) {
    ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text(e.toString())),
                      );
                    }
                  }
                },
                onGoToSignup: _toSignup,
              );
      },
        );
      },
    );
  }

  Future<void> _initialize() async {
    await _auth.init();
    _hasAnyUsers = await _auth.hasUsers();
  }
}

class AuthProvider extends InheritedWidget {
  final AuthService auth;
  const AuthProvider({Key? key, required this.auth, required Widget child}) : super(key: key, child: child);

  static AuthService of(BuildContext context) {
    final AuthProvider? provider = context.dependOnInheritedWidgetOfExactType<AuthProvider>();
    assert(provider != null, 'No AuthProvider found in context');
    return provider!.auth;
  }

  @override
  bool updateShouldNotify(covariant AuthProvider oldWidget) => auth != oldWidget.auth;
}

class _AppBootstrap extends StatefulWidget {
  final AuthService auth;
  final Widget child;
  const _AppBootstrap({required this.auth, required this.child});

  @override
  State<_AppBootstrap> createState() => _AppBootstrapState();
}

class _AppBootstrapState extends State<_AppBootstrap> {
  final AppState _state = AppState();
  bool _ready = false;

  @override
  void initState() {
    super.initState();
    _state.init().then((_) => setState(() => _ready = true));
  }

  @override
  Widget build(BuildContext context) {
    if (!_ready) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    return AppStateProvider(
      state: _state,
      child: AuthProvider(auth: widget.auth, child: widget.child),
    );
  }
}

class _RootNavigator extends StatefulWidget {
  const _RootNavigator({Key? key}) : super(key: key);

  @override
  State<_RootNavigator> createState() => _RootNavigatorState();
}

class _RootNavigatorState extends State<_RootNavigator> {
  int _selectedIndex = 0;

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }


  @override
  Widget build(BuildContext context) {
    final app = AppStateProvider.of(context);
    final pages = <Widget>[
      HomeScreen(
        onOpenCart: () => setState(() => _selectedIndex = 3),
      ),
      const CategoriesScreen(),
      const FavoritesScreen(),
      const CartScreen(),
      const ProfileScreen(),
    ];

    return Scaffold(
      body: IndexedStack(
        index: _selectedIndex,
        children: pages,
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _selectedIndex,
        onDestinationSelected: _onItemTapped,
        destinations: [
          const NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          const NavigationDestination(icon: Icon(Icons.category_outlined), selectedIcon: Icon(Icons.category), label: 'Categories'),
          const NavigationDestination(icon: Icon(Icons.favorite_border), selectedIcon: Icon(Icons.favorite), label: 'Favorites'),
          NavigationDestination(
            icon: Stack(
              clipBehavior: Clip.none,
          children: [
                const Icon(Icons.shopping_cart_outlined),
                if (app.cartCount > 0)
                Positioned(
                    right: -6,
                    top: -6,
                    child: _CartBadge(count: app.cartCount),
                ),
              ],
            ),
            selectedIcon: Stack(
              clipBehavior: Clip.none,
                children: [
                const Icon(Icons.shopping_cart),
                if (app.cartCount > 0)
                          Positioned(
                    right: -6,
                    top: -6,
                    child: _CartBadge(count: app.cartCount),
                      ),
                    ],
                  ),
            label: 'Cart',
            ),
          const NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }
}

class _CartBadge extends StatelessWidget {
  final int count;
  const _CartBadge({Key? key, required this.count}) : super(key: key);

  @override
  Widget build(BuildContext context) {
                            return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                decoration: BoxDecoration(
        color: Colors.red,
        borderRadius: BorderRadius.circular(10),
                                ),
                                child: Text(
        '$count',
        style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold),
      ),
    );
  }
}