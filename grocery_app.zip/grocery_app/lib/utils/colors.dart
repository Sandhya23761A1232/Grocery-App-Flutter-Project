import 'package:flutter/material.dart';

class AppColors {
  static const Color primary = Color(0xFF00C569);
  static const Color secondary = Color(0xFF2C3E50);
  static const Color accent = Color(0xFFFF6B35);
  static const Color background = Color(0xFFF8F9FA);
  static const Color textDark = Color(0xFF2C3E50);
  static const Color textLight = Color(0xFF95A5A6);
  static const Color cardBackground = Colors.white;
}