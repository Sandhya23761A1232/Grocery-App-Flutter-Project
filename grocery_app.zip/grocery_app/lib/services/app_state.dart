import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';

class AppState extends ChangeNotifier {
  final Set<String> _favoriteProductIds = <String>{};
  final Map<String, int> _cartProductIdToQty = <String, int>{};
  String _profileName = '';
  String _profileAddress = '';
  bool _initialized = false;

  Set<String> get favoriteProductIds => _favoriteProductIds;
  Map<String, int> get cart => _cartProductIdToQty;
  String get profileName => _profileName;
  String get profileAddress => _profileAddress;

  Future<void> init() async {
    if (_initialized) return;
    final prefs = await SharedPreferences.getInstance();
    final favs = prefs.getStringList('app.favorites') ?? <String>[];
    _favoriteProductIds
      ..clear()
      ..addAll(favs);
    final cartJson = prefs.getString('app.cart');
    if (cartJson != null) {
      final map = (json.decode(cartJson) as Map).cast<String, dynamic>();
      _cartProductIdToQty
        ..clear()
        ..addAll(map.map((k, v) => MapEntry(k, (v as num).toInt())));
    }
    _profileName = prefs.getString('app.profile.name') ?? '';
    _profileAddress = prefs.getString('app.profile.address') ?? '';
    _initialized = true;
    notifyListeners();
  }

  bool isFavorite(String productId) => _favoriteProductIds.contains(productId);

  Future<void> toggleFavorite(String productId) async {
    if (isFavorite(productId)) {
      _favoriteProductIds.remove(productId);
    } else {
      _favoriteProductIds.add(productId);
    }
    await _persistFavorites();
    notifyListeners();
  }

  Future<void> addToCart(String productId, {int quantity = 1}) async {
    if (quantity <= 0) return;
    _cartProductIdToQty.update(productId, (q) => q + quantity, ifAbsent: () => quantity);
    await _persistCart();
    notifyListeners();
  }

  Future<void> incrementQty(String productId) async {
    if (!_cartProductIdToQty.containsKey(productId)) return;
    _cartProductIdToQty.update(productId, (q) => q + 1);
    await _persistCart();
    notifyListeners();
  }

  Future<void> decrementQty(String productId) async {
    if (!_cartProductIdToQty.containsKey(productId)) return;
    final newQty = _cartProductIdToQty[productId]! - 1;
    if (newQty <= 0) {
      _cartProductIdToQty.remove(productId);
    } else {
      _cartProductIdToQty[productId] = newQty;
    }
    await _persistCart();
    notifyListeners();
  }

  Future<void> removeFromCart(String productId) async {
    _cartProductIdToQty.remove(productId);
    await _persistCart();
    notifyListeners();
  }

  Future<void> clearCart() async {
    _cartProductIdToQty.clear();
    await _persistCart();
    notifyListeners();
  }

  int get cartCount => _cartProductIdToQty.values.fold<int>(0, (acc, q) => acc + q);

  Future<void> updateProfile({String? name, String? address}) async {
    final prefs = await SharedPreferences.getInstance();
    if (name != null) {
      _profileName = name;
      await prefs.setString('app.profile.name', name);
    }
    if (address != null) {
      _profileAddress = address;
      await prefs.setString('app.profile.address', address);
    }
    notifyListeners();
  }

  Future<void> _persistFavorites() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList('app.favorites', _favoriteProductIds.toList());
  }

  Future<void> _persistCart() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('app.cart', json.encode(_cartProductIdToQty));
  }
}

class AppStateProvider extends InheritedNotifier<AppState> {
  final AppState state;
  const AppStateProvider({super.key, required this.state, required super.child})
      : super(notifier: state);

  static AppState of(BuildContext context) {
    final AppStateProvider? provider = context.dependOnInheritedWidgetOfExactType<AppStateProvider>();
    assert(provider != null, 'No AppStateProvider found in context');
    return provider!.state;
  }
}

