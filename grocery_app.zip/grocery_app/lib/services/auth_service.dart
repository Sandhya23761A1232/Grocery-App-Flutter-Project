import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';

class AuthUser {
  final String name;
  final String email;
  const AuthUser({required this.name, required this.email});
}

class AuthService extends ChangeNotifier {
  AuthUser? _currentUser;
  bool _initialized = false;

  AuthUser? get currentUser => _currentUser;
  bool get isLoggedIn => _currentUser != null;

  Future<void> init() async {
    if (_initialized) return;
    final prefs = await SharedPreferences.getInstance();
    final jsonUser = prefs.getString('auth.currentUser');
    if (jsonUser != null) {
      final map = json.decode(jsonUser) as Map<String, dynamic>;
      _currentUser = AuthUser(name: map['name'] as String, email: map['email'] as String);
    }
    _initialized = true;
    notifyListeners();
  }

  Future<bool> hasUsers() async {
    final prefs = await SharedPreferences.getInstance();
    final usersJson = prefs.getString('auth.users');
    if (usersJson == null) return false;
    final users = (json.decode(usersJson) as List);
    return users.isNotEmpty;
  }

  Future<void> login({required String email, required String password}) async {
    final prefs = await SharedPreferences.getInstance();
    final usersJson = prefs.getString('auth.users');
    if (usersJson == null) {
      throw AuthException('No account found for this email');
    }
    final users = (json.decode(usersJson) as List).cast<Map<String, dynamic>>();
    final user = users.firstWhere(
      (u) => (u['email'] as String).toLowerCase() == email.toLowerCase(),
      orElse: () => {},
    );
    if (user.isEmpty || user['password'] != password) {
      throw AuthException('Invalid email or password');
    }
    _currentUser = AuthUser(name: user['name'] as String, email: user['email'] as String);
    await prefs.setString('auth.currentUser', json.encode({'name': _currentUser!.name, 'email': _currentUser!.email}));
    notifyListeners();
  }

  Future<void> signup({required String name, required String email, required String password}) async {
    final prefs = await SharedPreferences.getInstance();
    final usersJson = prefs.getString('auth.users');
    final users = usersJson == null ? <Map<String, dynamic>>[] : (json.decode(usersJson) as List).cast<Map<String, dynamic>>();
    final exists = users.any((u) => (u['email'] as String).toLowerCase() == email.toLowerCase());
    if (exists) {
      throw AuthException('Email already in use');
    }
    final newUser = {'name': name, 'email': email, 'password': password};
    users.add(newUser);
    await prefs.setString('auth.users', json.encode(users));
    // Do not auto-login after signup; require explicit login.
    notifyListeners();
  }

  Future<void> logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('auth.currentUser');
    _currentUser = null;
    notifyListeners();
  }
}

class AuthException implements Exception {
  final String message;
  AuthException(this.message);
  @override
  String toString() => message;
}


