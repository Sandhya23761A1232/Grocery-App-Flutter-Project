import 'package:flutter/material.dart';
import '../utils/colors.dart';
import '../services/app_state.dart';
import '../utils/dummy_data.dart';
import '../models/product.dart';

class CartScreen extends StatelessWidget {
  const CartScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final app = AppStateProvider.of(context);
    return AnimatedBuilder(
      animation: app,
      builder: (context, _) {
        final cartMap = app.cart;
        final items = <_CartItem>[];
        double total = 0;
        for (final entry in cartMap.entries) {
          final matches = DummyData.products.where((p) => p.id == entry.key);
          if (matches.isNotEmpty) {
            final product = matches.first;
            final qty = entry.value;
            final price = product.price * qty;
            total += price;
            items.add(_CartItem(product: product, qty: qty, price: price));
          }
        }

        return Scaffold(
          appBar: AppBar(title: const Text('Your Cart')),
          body: items.isEmpty
              ? const _EmptyCart()
              : Column(
                  children: [
                    Expanded(
                      child: ListView.separated(
                        padding: const EdgeInsets.all(16),
                        itemBuilder: (context, index) {
                          final item = items[index];
                          return _CartTile(item: item);
                        },
                        separatorBuilder: (_, __) => const Divider(height: 1),
                        itemCount: items.length,
                      ),
                    ),
                    _CartSummary(total: total),
                  ],
                ),
        );
      },
    );
  }
}

class _EmptyCart extends StatelessWidget {
  const _EmptyCart();

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: const [
            Icon(Icons.remove_shopping_cart_outlined, size: 64, color: Colors.grey),
            SizedBox(height: 12),
            Text('Your cart is empty', style: TextStyle(fontSize: 16, color: Colors.grey)),
          ],
        ),
      ),
    );
  }
}

class _CartItem {
  final Product product;
  final int qty;
  final double price;
  _CartItem({required this.product, required this.qty, required this.price});
}

class _CartTile extends StatelessWidget {
  final _CartItem item;
  const _CartTile({required this.item});

  @override
  Widget build(BuildContext context) {
    final app = AppStateProvider.of(context);
    return ListTile(
      leading: CircleAvatar(backgroundColor: Colors.grey[200], child: Text(item.product.name.characters.first)),
      title: Text(item.product.name),
      subtitle: Text('₹${item.product.price.toStringAsFixed(0)} · Qty: ${item.qty}'),
      trailing: SizedBox(
        width: 140,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            IconButton(icon: const Icon(Icons.remove_circle_outline), onPressed: () => app.decrementQty(item.product.id)),
            Text('${item.qty}'),
            IconButton(icon: const Icon(Icons.add_circle_outline), onPressed: () => app.incrementQty(item.product.id)),
            IconButton(icon: const Icon(Icons.delete_outline), onPressed: () => app.removeFromCart(item.product.id)),
          ],
        ),
      ),
    );
  }
}

class _CartSummary extends StatelessWidget {
  final double total;
  const _CartSummary({required this.total});

  @override
  Widget build(BuildContext context) {
    final app = AppStateProvider.of(context);
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('Total', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              Text('₹${total.toStringAsFixed(0)}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: AppColors.primary)),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: () => app.clearCart(),
                  child: const Text('Clear Cart'),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: ElevatedButton(
                  onPressed: itemsGuarded(total) ? () {} : null,
                  style: ElevatedButton.styleFrom(backgroundColor: AppColors.primary, foregroundColor: Colors.white),
                  child: const Text('Checkout'),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  bool itemsGuarded(double t) => t > 0;
}



