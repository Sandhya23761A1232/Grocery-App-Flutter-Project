import 'package:flutter/material.dart';
import '../services/app_state.dart';
import '../utils/dummy_data.dart';
import '../models/product.dart';

class FavoritesScreen extends StatelessWidget {
  const FavoritesScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final app = AppStateProvider.of(context);
    return AnimatedBuilder(
      animation: app,
      builder: (context, _) {
        final favIds = app.favoriteProductIds;
        final products = DummyData.products.where((p) => favIds.contains(p.id)).toList();
        return Scaffold(
          appBar: AppBar(title: const Text('Favorites')),
          body: products.isEmpty
              ? const _EmptyFavorites()
              : ListView.separated(
                  padding: const EdgeInsets.all(16),
                  itemCount: products.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 12),
                  itemBuilder: (context, index) {
                    final product = products[index];
                    return _FavoriteTile(product: product);
                  },
                ),
        );
      },
    );
  }
}

class _EmptyFavorites extends StatelessWidget {
  const _EmptyFavorites();

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: const [
            Icon(Icons.favorite_border, size: 64, color: Colors.grey),
            SizedBox(height: 12),
            Text('No favorites yet', style: TextStyle(fontSize: 16, color: Colors.grey)),
          ],
        ),
      ),
    );
  }
}

class _FavoriteTile extends StatelessWidget {
  final Product product;
  const _FavoriteTile({required this.product});

  @override
  Widget build(BuildContext context) {
    final app = AppStateProvider.of(context);
    return ListTile(
      leading: CircleAvatar(
        backgroundColor: Colors.grey[200],
        child: Text(product.name.characters.first),
      ),
      title: Text(product.name, maxLines: 1, overflow: TextOverflow.ellipsis),
      subtitle: Text('₹${product.price.toStringAsFixed(0)}/${product.unit}'),
      trailing: Wrap(
        spacing: 8,
        children: [
          IconButton(
            icon: const Icon(Icons.add_shopping_cart_outlined),
            onPressed: () => app.addToCart(product.id),
            tooltip: 'Add to cart',
          ),
          IconButton(
            icon: const Icon(Icons.delete_outline),
            onPressed: () => app.toggleFavorite(product.id),
            tooltip: 'Remove',
          ),
        ],
      ),
    );
  }
}



