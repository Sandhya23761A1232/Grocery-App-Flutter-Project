import 'package:flutter/material.dart';
import '../main.dart';
import '../services/app_state.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final auth = AuthProvider.of(context);
    final app = AppStateProvider.of(context);
    return Scaffold(
      appBar: AppBar(title: const Text('Profile')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const SizedBox(height: 8),
          Center(
            child: Stack(
              children: [
                const CircleAvatar(radius: 44, child: Icon(Icons.person, size: 44)),
                Positioned(
                  right: 0,
                  bottom: 0,
                  child: CircleAvatar(
                    radius: 14,
                    child: IconButton(
                      padding: EdgeInsets.zero,
                      iconSize: 16,
                      onPressed: () {},
                      icon: const Icon(Icons.edit, size: 16),
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          Center(
            child: Text(
              app.profileName.isNotEmpty ? app.profileName : (auth.currentUser?.name ?? 'Guest'),
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
          ),
          if (auth.currentUser != null)
            Center(child: Text(auth.currentUser!.email, style: const TextStyle(color: Colors.grey))),
          const SizedBox(height: 16),
          const Divider(),
          const SizedBox(height: 8),
          const Text('Profile', style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          _EditableField(
            label: 'Name',
            initialValue: app.profileName.isNotEmpty ? app.profileName : (auth.currentUser?.name ?? ''),
            onSave: (v) => app.updateProfile(name: v.trim()),
          ),
          const SizedBox(height: 12),
          _EditableField(
            label: 'Address',
            initialValue: app.profileAddress,
            onSave: (v) => app.updateProfile(address: v.trim()),
          ),
          const SizedBox(height: 24),
          const Divider(),
          const ListTile(leading: Icon(Icons.settings_outlined), title: Text('Settings')),
          const ListTile(leading: Icon(Icons.help_outline), title: Text('Help & Support')),
          const ListTile(leading: Icon(Icons.info_outline), title: Text('About')),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            height: 44,
            child: ElevatedButton(
              onPressed: () async {
                await auth.logout();
                if (context.mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Logged out')));
                }
              },
              child: const Text('Log out'),
            ),
          ),
          const SizedBox(height: 24),
        ],
      ),
    );
  }
}

class _EditableField extends StatefulWidget {
  final String label;
  final String initialValue;
  final Future<void> Function(String) onSave;
  const _EditableField({required this.label, required this.initialValue, required this.onSave});

  @override
  State<_EditableField> createState() => _EditableFieldState();
}

class _EditableFieldState extends State<_EditableField> {
  late final TextEditingController _controller;
  bool _editing = false;

  @override
  void initState() {
    super.initState();
    _controller = TextEditingController(text: widget.initialValue);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: TextField(
            controller: _controller,
            readOnly: !_editing,
            decoration: InputDecoration(
              labelText: widget.label,
              suffixIcon: IconButton(
                icon: Icon(_editing ? Icons.check : Icons.edit),
                onPressed: () async {
                  if (_editing) {
                    await widget.onSave(_controller.text);
                  }
                  setState(() => _editing = !_editing);
                },
              ),
            ),
          ),
        ),
      ],
    );
  }
}


