class Product {
  final String id;
  final String name;
  final double price;
  final String unit;
  final String image;
  final String category;
  final double rating;
  final String description;

  Product({
    required this.id,
    required this.name,
    required this.price,
    required this.unit,
    required this.image,
    required this.category,
    required this.rating,
    required this.description,
  });
}